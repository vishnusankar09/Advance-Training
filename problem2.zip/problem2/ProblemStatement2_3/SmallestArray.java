package ProblemStatement2;

public class SmallestArray {
	
	int arr[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};

}
