package ProblemStatement2;

public class AverageArray {
	
	static int arr[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
	  static int sum =0;
	public static  int average()
	{
		for(int i=0;i<arr.length-4;i++)
		{
			sum += arr[i];
		}
		return arr[15] =sum/2;
	}
	public static void main(String[] args)
	{
	    System.out.println("The average of first 15 numbers:" +average());
	    
	    for(int i=0;i<arr.length;i++)
	    {
	    	System.out.println(arr[i]);
	    }
	}

}
