package problemstatement4;

import java.util.Scanner;

public class BankAccount {
int accountnumber ;
String custumername;
String accounttype;
String accounttype1;
float balance;
BankAccount( int accountnumber , String custumername ,String accounttype, float balance,String accounttype1)

{
	this.accountnumber = accountnumber;
	this.custumername =custumername;
	this.accounttype =accounttype;
	this.balance = balance;
	this.accounttype1=accounttype1;
	}

public void deposit( float amt)
{
	if(this.balance<0)
	{
		System.out.println("Credit will not be possible " );
	}
	else
	{
		this.balance+=amt;
		System.out.println("Amount is successfully depoist: " +this.balance);
	}
}

public void withdrawSavingAcc(float amt)
{
	if(this.balance>=1000 )
	{
		this.balance -= amt;
		System.out.println("Succesffully withdrawn from savingAccount: " +this.balance);
	}
	else
	{
	System.out.println(" Failed!...The Minimum balance should be 1000");
	}
}
public void withdrawCurrentAcc(float amt)
{
	System.out.println("The withdrawn money is"+amt);
	if(this.balance>=5000)
	{
		this.balance -= amt;
		System.out.println(" after Succesffully withdrawn from current account: " +this.balance);
	}
	else
	{
	System.out.println(" Failed!...The Minimum balance should be 5000");
	}
}
public void currentbalence()
{
	if(this.balance<1000)
	{
		System.out.println("your balance is low :" +this.balance);
	}
	else
	{
	  System.out.println("The current balance after withdraw: "+this.balance);
	}
}
	
public static void main(String[] args)
{
	BankAccount b1 = new BankAccount(123 , "vinay" , "saving", 2000 , "current");
	       b1.deposit(10000);
	      // b1.withdrawCurrentAcc(5000);
	       b1.withdrawSavingAcc(1000);
	       b1.currentbalence();
	}
}
