package product_Statement_6_3;

import java.util.LinkedList;
import java.util.List;

public class Employee {
	
	int empno;
	String name;
	String Adress;
  Employee(int empno,String name,String Adress)
  {
	  this.empno=empno;
	  this.name=name;
	  this.Adress=Adress;
  }
  static LinkedList l3;
  public void addinput()
  {
	 new LinkedList<String>();
	l3.add(1);
	l3.add("Datta");
	l3.add("1-2, selapaka east");
  }
  public static void display()
  {
	  
  }
	
public static void main(String[] args)
{
      Employee e1 = new Employee(111, "vinay", "hyderabad");
      Employee e2 = new Employee(112, "Sai", "hyderabad");
      Employee e3 = new Employee(113, "Datta", "hyderabad");
      Employee e4 = new Employee(114, "Hello", "hyderabad");
            LinkedList<Employee> l1 = new LinkedList<Employee>();
            l1.add(e1);
            l1.add(e2);
            l1.add(e3);
            l1.add(e4);
          for(Employee e:l1)
          {
        	 System.out.println(e.empno);
        	 System.out.println(e.name);
        	 System.out.println(e.Adress);
        	 
          }
	}
}
