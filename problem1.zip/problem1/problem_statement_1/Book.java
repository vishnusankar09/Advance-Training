package EvenNumber;

import java.util.Scanner;

public class Book {
	
	String book_title;
	private int book_price;
	public String getBook_title() {
		return book_title;
	}
	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}
	public int getBook_price() {
		return book_price;
	}
	public void setBook_price(int book_price) {
		this.book_price = book_price;
	}	 
	 public static void main(String[] args)
	 {
		  
		 Scanner s1 = new Scanner(System.in);
		 System.out.println("Enter the book title");
		String title =s1.nextLine();
		Scanner s2 = new Scanner(System.in);
		System.out.println("Enter the price of the book");
		int price = s2.nextInt();
		Book b1 = new Book();
		b1.setBook_title(title);
		b1.setBook_price(price);
		System.out.println("The Title of the book: " +b1.getBook_title());
		System.out.println("The price of the book" +b1.getBook_price());
		
		
		 
		 
	 }

}
