package program8_1;

public class Counter123 {

	public static void main(String args[])

	{

	Counter counter = new Counter(5);

	counter.run();

	}

}
