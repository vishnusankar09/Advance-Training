package Abstract_Class_and_Interface32;

public class ointment implements medicoinfo {

	@Override
	public void displaydetails() {
	       System.out.println("ointmemt should not be expore to the sunlight");
		
	}

}
